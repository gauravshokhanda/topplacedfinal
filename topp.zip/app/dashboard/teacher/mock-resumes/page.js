export default function TeacherMockResumes() {
    return <h1>Mock Resumes Section</h1>;
  }
  