export default function TeacherHome() {
    return <h1>Teacher Home Page</h1>;
  }
  