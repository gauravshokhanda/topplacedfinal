export default function TeacherBooking() {
    return <h1>Booking Management</h1>;
  }
  