export default function TeacherJobCard() {
    return <h1>Job Card Section</h1>;
  }
  