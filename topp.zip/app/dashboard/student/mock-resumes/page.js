import ResumeUpload from "@/components/ResumeUpload";
import { Box } from "@mui/material";

export default function TeacherMockResumes() {
    return <Box><ResumeUpload/></Box>;
  }
  