import LandingPage from "@/components/Landing/LandingPage";

export default function Home() {
  return <LandingPage />;
}
